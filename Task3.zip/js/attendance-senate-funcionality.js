var dataR = data.results[0].members

function getMembersByParty(PartyMembers) {
  var members = dataR.filter(member => member.party == PartyMembers)
  return members;
}


var republicans = getMembersByParty("R");
var democrats = getMembersByParty("D");
var independents = getMembersByParty("I");

function getAverage(PartyArraymMembers) {
  return (PartyArraymMembers.reduce((accumulator, member) => accumulator + member.votes_with_party_pct, 0) / PartyArraymMembers.length).toFixed(2);
}

function leastOftenVoteWithParty (data,votesvar)
{
let dataOrd = data.sort((a, b) => (a[votes] - b[votes])) ;//ordena el array por votos
let   posPersent = Math.ceil((10 * dataOrd.length)/100)-1 ; // entero superior del 10%
let valuePositionPersent = dataOrd[posPersent][votesvar] // valor de la posicion del porcentaje
let dataFilter; //do later

}


statistics.numbers_of_republicans = republicans.length;
statistics.numbers_of_democrats = democrats.length;
statistics.numbers_of_independents = independents.length;

statistics.average_votes_party_democrats = getAverage(democrats);
statistics.average_votes_party_republicans = getAverage(republicans);
statistics.average_votes_party_independents = getAverage(independents);