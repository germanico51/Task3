var statistics = {
    "numbers_of_republicans": 0,
    "numbers_of_democrats": 0,
    "numbers_of_independents": 0,
    "numbers_of_total": 0,

    "average_votes_party_republicants": 0,
    "average_votes_party_democrats": 0,
    "average_votes_party_independents": 0,
    "average_votes_party_total": 0,

    "least_loyal": [],
    "most_loyal": [],
    "least_engaged": [],
    "most_engaged": [],
}
